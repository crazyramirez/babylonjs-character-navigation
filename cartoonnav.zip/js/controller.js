// Navigation //
var isWPressed = false;
var isSPressed = false;
var isAPressed = false;
var isDPressed = false;

// Speed Movement
var speedMovement = 0.002;
var joystickSpeedMovement = 0.005;

// Player Movement //
function setPlayerMovement() {

    // Mobile Device
    if (isTouch) {
        setJoystickController();
        return;
    }

    // Set Rotation Axis
    var rotationAxis;

    scene.registerBeforeRender(()=>{
        var dt = engine.getDeltaTime();

        // Run Forward
        if (isWPressed) {
            // walkAnim.setWeightForAllAnimatables(0.4);
            scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, runAnim,  1.2));
            currentAnim = runAnim;

            var frontVector = player[0].getDirection(new BABYLON.Vector3(0,0,1)).scale(speedMovement*dt*3);
            player[0].moveWithCollisions(frontVector);
        }
        // Run Backward
        if (isSPressed) {
            // walkAnim.setWeightForAllAnimatables(0.4);
            scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, runBackAnim, 1.5));
            currentAnim = runBackAnim;

            var frontVector = player[0].getDirection(new BABYLON.Vector3(0,0,1)).scale(-speedMovement*dt*3);
            player[0].moveWithCollisions(frontVector);
        }
        // Rotate Left
        if (isAPressed) {
            rotationAxis = new BABYLON.Vector3(0, -1, 0);
        }
        // Rotate Right
        if (isDPressed) {
            rotationAxis = new BABYLON.Vector3(0, 1, 0);
        }
        
        // Rotate actions
        if (isAPressed || isDPressed)
        {
            player[0].rotate(rotationAxis, speedMovement*dt, BABYLON.Space.LOCAL);
            player[0].frontVector = new BABYLON.Vector3(Math.sin(player[0].rotation.z), 0, Math.cos(player[0].rotation.z))

            // Check if Player is currently moving
            if (isSPressed == false && isWPressed == false) {
                currentAnim = walkAnim;
                scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, walkAnim, 0.9));
            }
        }

        // Check Idle Animation
        if (! isWPressed && ! isSPressed && ! isAPressed && ! isDPressed) {
            currentAnim = idleAnim;
            scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, idleAnim, 1.0));
        }
    });
}

// Animation Blending //
var blendingSpeed = 0.03;
function* animationBlending (fromAnim, toAnim, speed) {
    toAnim.start(false, speed, toAnim.from, toAnim.to, false);
    let currentWeight = 1;
    let newWeight = 0;
    while (newWeight < 1) {
        newWeight += blendingSpeed;
        currentWeight -= blendingSpeed;
        toAnim.setWeightForAllAnimatables(newWeight);
        fromAnim.setWeightForAllAnimatables(currentWeight);
        yield;
    }
}


// Keyboard Actions KeyDown//
document.addEventListener("keydown", function (event) {
    if (event.key == 'w' || event.key == 'W' || event.key == "ArrowUp") {
        isWPressed = true;
    }
    if (event.key == 's' || event.key == 'S' || event.key == "ArrowDown") {
        isSPressed = true;
    }
    if (event.key == 'a' || event.key == 'A' || event.key == "ArrowLeft") {
        isAPressed = true;
    }
    if (event.key == 'd' || event.key == 'D' || event.key == "ArrowRight") {
        isDPressed = true;
    }
});

// Keyboard Actions KeyUp//
document.addEventListener("keyup", function (event) {
    if (event.key == 'w' || event.key == 'W' || event.key == "ArrowUp") {
        isWPressed = false;
    }
    if (event.key == 's' || event.key == 'S' || event.key == "ArrowDown") {
        isSPressed = false;
    }
    if (event.key == 'a' || event.key == 'A' || event.key == "ArrowLeft") {
        isAPressed = false;
    }
    if (event.key == 'd' || event.key == 'D' || event.key == "ArrowRight") {
        isDPressed = false;
    }
});

// Virtual Joystick Actions //
function setJoystickController() {

    // Default Joysticks
    var leftJoystick = new BABYLON.VirtualJoystick(true);
    var rightJoystick = new BABYLON.VirtualJoystick(false);
    leftJoystick.setJoystickColor("#b3dbbf");
    rightJoystick.setJoystickColor("#b3dbbf");
    BABYLON.VirtualJoystick.Canvas.style.zIndex = "4";
    
    scene.registerBeforeRender(()=>{

        var dt = engine.getDeltaTime();
        // moveX = rightJoystick.deltaPosition.x * (engine.getDeltaTime() / 10);
        // moveZ = leftJoystick.deltaPosition.y * (engine.getDeltaTime() / 10);

        // Move Forward or Backward
        if (leftJoystick.pressed && leftJoystick.deltaPosition.y != 0) {
            var frontVector = player[0].getDirection(BABYLON.Axis.Z).scale(leftJoystick.deltaPosition.y*joystickSpeedMovement*dt);
            player[0].moveWithCollisions(frontVector);

            if (leftJoystick.deltaPosition.y > 0)
            {
                scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, runAnim, 1.2));
                currentAnim = runAnim;
            } else if (leftJoystick.deltaPosition.y < 0) {
                scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, runBackAnim, 1.5));
                currentAnim = runBackAnim;
            }
            
        } else {
            leftJoystick.deltaPosition.y = 0;
        }

        // Rotate Left or Right
        if (rightJoystick.pressed) {

            var rotationAxis = new BABYLON.Vector3(0, 1, 0)
            player[0].rotate(rotationAxis, rightJoystick.deltaPosition.x*speedMovement*dt, BABYLON.Space.LOCAL);
            player[0].frontVector = new BABYLON.Vector3(Math.sin(player[0].rotation.z), 0, Math.cos(player[0].rotation.z))
            
            // Check if Player is currently moving
            if (!leftJoystick.pressed && rightJoystick.deltaPosition.x != 0)
            {
                currentAnim = walkAnim;
                scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, walkAnim, 1.0));
            }
        } else {
            rightJoystick.deltaPosition.x = 0;
        }

        // Check Idle Animation
        if (!leftJoystick.pressed && !rightJoystick.pressed) {
            currentAnim = idleAnim;
            scene.onBeforeRenderObservable.runCoroutineAsync(animationBlending(currentAnim, idleAnim, 1.0));
        }
    });
}